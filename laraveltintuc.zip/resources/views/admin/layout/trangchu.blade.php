
@extends('admin.layout.index')

@section('content')





<div id="content">

 <div id="content-header">
    <div id="breadcrumb"> <a href="admin/trangchu.html" title="Quay lại trang chủ" class="tip-bottom"><i class="icon-home"></i> </a> </div> 
  </div>



  
  <div class="container-fluid">

  
    <div class="row-fluid"></div>
  </div>
</div>
    @endsection
