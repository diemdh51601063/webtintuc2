<?php $__env->startSection('content'); ?>





<div id="content">

 <div id="content-header">
    <div id="breadcrumb"> <a href="admin/trangchu.html" title="Quay lại trang chủ" class="tip-bottom"><i class="icon-home"></i> </a> </div> 
  </div>



  
  <div class="container-fluid">

  
    <div class="row-fluid"></div>
  </div>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laraveltintuc\resources\views/admin/layout/trangchu.blade.php ENDPATH**/ ?>