<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('content2'); ?>
<div>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($value->trangthai==0): ?>
    continue;
<?php endif; ?>
<div class="card mb-3" style="max-width: 720px; border-bottom: 0px;border-right: 0px; border-left: 0px;">
  <div class="row no-gutters">
    <div class="col-md-4">
     <a href="<?php echo e($value->tieudeseo); ?>-post<?php echo e($value->id); ?>.html"> <img  style="width: 240px;height: 223px;" src="upload/tintuc/<?php echo e($value->hinhdaidien); ?>" class="card-img" alt="<?php echo e($value->mota); ?>"></a>
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><a href="<?php echo e($value->tieudeseo); ?>-post<?php echo e($value->id); ?>.html"><?php echo e($value->tieude); ?></a></h5>
        <p class="card-text"><a style="color: black;" href="<?php echo e($value->loaitin->loaitinseo); ?>.html"><?php echo e($value->loaitin->tenloaitin); ?></a></p>
        <p class="card-text"><?php 
        if(strlen($value->noidung)>120)
        echo substr($value->noidung,0,strpos($value->noidung,' ',120)); ?>...</p>
        <br>
        <p class="card-text"><small class="text-muted"><?php echo e($value->ngaydangtin); ?></small></p>
      <!--  <p class="card-text">28-04-2020 06:25:29</p>-->
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laraveltintuc\resources\views/front/category.blade.php ENDPATH**/ ?>