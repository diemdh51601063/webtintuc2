<?php $__env->startSection('content'); ?>

<small class="text-muted">Tìm thấy <?php echo e($soluong); ?> tin</small>

<br>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content2'); ?>


<?php $__currentLoopData = $dstin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card mb-3" style="max-width: 720px; border-bottom: 0px;border-right: 0px; border-left: 0px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img style="max-width: 240px;max-height: 223px;" src="upload/tintuc/<?php echo e($value->hinhdaidien); ?>" class="card-img" alt="$value->mota">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><a href="<?php echo e($value->tieudeseo); ?>-post<?php echo e($value->id); ?>.html"><?php echo e($value->tieude); ?></a></h5>
        <p class="card-text"><?php echo substr($value->noidung,0,strpos($value->noidung,'.')); ?>.</p>
       
        <p class="card-text"><?php echo e($value->ngaydangtin); ?></p>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laraveltintuc\resources\views/front/search.blade.php ENDPATH**/ ?>