<?php $__env->startSection('trend'); ?>

<!-- Trending Area Start -->
    <div class="trending-area fix">
        <div class="container">
            <div class="trending-main">
                <!-- Trending Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="trending-tittle">
                            
                            <!-- <p>Rem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                            <div class="trending-animated"></div>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8">
                        <!-- Trending Top -->
                        <div class="trending-top mb-30">
                            <div class="trend-top-img">
                                <img src="upload\tintuc\<?php echo e($data[0]->hinhdaidien); ?>" alt="<?php echo e($data[0]->mota); ?>">
                                <div class="trend-top-cap">
                                    <span><?php echo e($data[0]->loaitin->tenloaitin); ?></span>
                                    <h2><a href="<?php echo e($data[0]->tieudeseo); ?>-post<?php echo e($data[0]->id); ?>.html"><?php echo e($data[0]->tieude); ?></a></h2>
                                </div>
                            </div>
                        </div>
                        <!-- Trending Bottom -->
                        <div class="row">
                        <div class="col-lg-6">
                        <div class="trand-right-single d-flex">
                            <div class="trand-right-img">
                                <img style="width: 120px;height: 100px;" src="upload\tintuc\<?php echo e($data[1]->hinhdaidien); ?>" alt="<?php echo e($data[1]->mota); ?>">
                            </div>
                            <div class="trand-right-cap">
                                <span class="color1"><?php echo e($data[1]->loaitin->tenloaitin); ?></span>
                                <h4><a href="<?php echo e($data[1]->tieudeseo); ?>-post<?php echo e($data[1]->id); ?>.html"><?php echo e($data[1]->tieude); ?></a></h4>
                            </div>
                        </div>
                        <div class="trand-right-single d-flex">
                            <div class="trand-right-img">
                                <img style="width: 120px;height: 100px;" src="upload\tintuc\<?php echo e($data[2]->hinhdaidien); ?>" alt="<?php echo e($data[2]->mota); ?>">
                            </div>
                            <div class="trand-right-cap">
                                <span class="color1"><?php echo e($data[2]->loaitin->tenloaitin); ?></span>
                                <h4><a href="<?php echo e($data[2]->tieudeseo); ?>-post<?php echo e($data[2]->id); ?>.html"><?php echo e($data[2]->tieude); ?></a></h4>
                            </div>
                        </div>
                        
                      
                    </div> 


            <div class="col-lg-6">
                        <div class="trand-right-single d-flex">
                            <div class="trand-right-img">
                                <img style="width: 120px;height: 100px;" src="upload\tintuc\<?php echo e($data[3]->hinhdaidien); ?>" alt="<?php echo e($data[3]->mota); ?>">
                            </div>
                            <div class="trand-right-cap">
                                <span class="color1"><?php echo e($data[3]->loaitin->tenloaitin); ?></span>
                                <h4><a href="<?php echo e($data[3]->tieudeseo); ?>-post<?php echo e($data[3]->id); ?>.html"><?php echo e($data[3]->tieude); ?></a></h4>
                            </div>
                        </div>
                        <div class="trand-right-single d-flex">
                            <div class="trand-right-img">
                                <img style="width: 120px;height: 100px;" src="upload\tintuc\<?php echo e($data[4]->hinhdaidien); ?>" alt="<?php echo e($data[4]->mota); ?>">
                            </div>
                            <div class="trand-right-cap">
                                <span class="color1"><?php echo e($data[4]->loaitin->tenloaitin); ?></span>
                                <h4><a href="<?php echo e($data[4]->tieudeseo); ?>-post<?php echo e($data[4]->id); ?>.html"><?php echo e($data[4]->tieude); ?></a></h4>
                            </div>
                        </div>
                        
                      
                    </div>
                </div>
                    </div>
                    <!-- Riht content -->
                    <div class="col-lg-4">

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key>4&&$key<10): ?>
                        <div class="trand-right-single d-flex">
                            <div class="trand-right-img">
                               <img style="width: 130px;height: 120px;" src="upload\tintuc\<?php echo e($val->hinhdaidien); ?>" alt="<?php echo e($val->mota); ?>">
                            </div>
                            <div class="trand-right-cap">
                               <span class="color1"><?php echo e($data[$key]->loaitin->tenloaitin); ?></span>
                                <h4><a href="<?php echo e($val->tieudeseo); ?>-post<?php echo e($val->id); ?>.html"><?php echo e($val->tieude); ?></a></h4>
                            </div>
                        </div>
             <?php endif; ?>
                        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Trending Area End -->
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>


                <div class="row d-flex justify-content-between">
                    <div class="col-lg-3 col-md-3">
                        <div class="section-tittle mb-30">
                            <h3>Tin Mới</h3>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-12">

    <div class="row">
    <div class="col-sm-12">
        <div id="content">



 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key>10): ?>

            <div class="card mb-3" style="max-width: 720px; border-bottom: 0px;border-right: 0px; border-left: 0px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img style="max-width: 240px;max-height: 223px;" class="card-img" src="upload\tintuc\<?php echo e($val->hinhdaidien); ?>" alt="<?php echo e($val->mota); ?>">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><a href="<?php echo e($val->tieudeseo); ?>-post<?php echo e($val->id); ?>.html"><?php echo e($val->tieude); ?></a></h5>
         <span class="" ><a style=" color: black;" href="<?php echo e($data[$key]->loaitin->loaitinseo); ?>.html"><?php echo e($data[$key]->loaitin->tenloaitin); ?></a></span>
       <p class="card-text"><?php 
        if(strlen($val->noidung)>150)
        echo substr($val->noidung,0,strpos($val->noidung,' ',150)); ?>...</p>
       
        <p class="card-text"><?php echo e($val->ngaydangtin); ?></p>
      </div>
    </div>
  </div>
</div>

   <?php endif; ?>
                        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div> 
</div>               
                    </div>
                </div>
            

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laraveltintuc\resources\views/front/index.blade.php ENDPATH**/ ?>